iconos:
https://www.webfx.com/tools/emoji-cheat-sheet/

informaicón sobre temas de streamlit:
https://blog.streamlit.io/introducing-theming/

formulario de contacto:
https://formsubmit.co/

para un .css básico para el formulario de contacto: 
https://www.w3schools.com/howto/howto_css_contact_form.asp

Ejecutar código:
streamlit run app.py

Desplegar código: 
https://share.streamlit.io/
